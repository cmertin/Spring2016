#ifndef DIMENSIONS_H
#define DIMENSIONS_H
#include <vector>

template <typename T>
struct Dimensions
{
  std::vector<T> x;
  std::vector<T> y;
};

#endif
