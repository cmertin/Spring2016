#include <iostream>
#include "vector.h"

using namespace std;

int main()
{
  Vector a;
  return 0;
}
